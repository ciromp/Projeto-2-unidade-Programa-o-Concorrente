import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Banheiro {
	
	private int capacidadeMax;
	private int qntHomensDentro;
	private int qntMulheresDentro;
	private int totalDentroBanheiro;
	
	private ReentrantLock bloqueio;
	
	private Condition homemPodeEntrar;
	private Condition mulherPodeEntrar;

	public Banheiro(int capacidadeMax) {
		super();
		// TODO Auto-generated constructor stub
		this.capacidadeMax  = capacidadeMax;
		qntMulheresDentro = 0;
		qntHomensDentro = 0;
		totalDentroBanheiro = 0;
		bloqueio = new ReentrantLock();
		homemPodeEntrar = bloqueio.newCondition();
		mulherPodeEntrar = bloqueio.newCondition();
		
	}
	
	
	public void entraMulher(Pessoa mulher) {
		bloqueio.lock();
		while(capacidadeMax == totalDentroBanheiro || qntHomensDentro > 0) {
			mulherPodeEntrar.awaitUninterruptibly();
		}
		
		qntMulheresDentro++;
		totalDentroBanheiro++;
		
		System.out.println("A mulher " + String.valueOf(mulher.getIdentificador()) + " ENTROU NO BANHEIRO! > PESSOAS NO BANHEIRO: "  + String.valueOf(totalDentroBanheiro) + " MULHER(ES)");
		
		bloqueio.unlock();
	}
	
	public void entraHomem(Pessoa homem) {
		bloqueio.lock();
		
		while(capacidadeMax == totalDentroBanheiro || qntMulheresDentro > 0) {
			homemPodeEntrar.awaitUninterruptibly();
		}
		
		qntHomensDentro++;
		totalDentroBanheiro++;
		
		System.out.println("O homem " + String.valueOf(homem.getIdentificador()) + " ENTROU no banheiro! > PESSOAS NO BANHEIRO: "  + String.valueOf(totalDentroBanheiro) + " HOMEM(ENS)");
		
		
		bloqueio.unlock();
	}
	
	public void saiMulher(Pessoa mulher) {
		bloqueio.lock();
		qntMulheresDentro--;
		totalDentroBanheiro--;
		if(qntMulheresDentro == 0) {
			homemPodeEntrar.signalAll();
			
		}
		System.out.println("A mulher " + String.valueOf(mulher.getIdentificador()) + " SAIU do banheiro! > PESSOAS NO BANHEIRO: "  + String.valueOf(totalDentroBanheiro) + "MULHER(ES)");
		bloqueio.unlock();
		
	}
	
	public void saiHomem(Pessoa homem) {
		bloqueio.lock();
		qntHomensDentro--;
		totalDentroBanheiro--;
		if(qntHomensDentro == 0) {
			mulherPodeEntrar.signalAll();
		}
		System.out.println("O homem " + String.valueOf(homem.getIdentificador()) + " SAIU do banheiro! > PESSOAS NO BANHEIRO: "  + String.valueOf(totalDentroBanheiro) + "HOMEM(ENS)");
		bloqueio.unlock();
	}
	

}
