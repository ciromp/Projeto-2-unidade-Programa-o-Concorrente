
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Banheiro banheiro = new Banheiro(Integer.parseInt(args[0]));
		int homens = Integer.parseInt(args[1]);
		int mulheres = Integer.parseInt(args[2]);
		
		
		for (int i = 0;i < homens;i++) {
			Pessoa homem = new Pessoa("Homem", i);
			Thread threadHomem = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while(true) {
						banheiro.entraHomem(homem);
						
						try {
							Thread.sleep(homem.tempoDentroOuFora());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						banheiro.saiHomem(homem);
						
						try {
							Thread.sleep(homem.tempoDentroOuFora());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}, "Homem " + String.valueOf(homem.getIdentificador()));
			
			threadHomem.start();
		}
		
		for (int i = 0;i < mulheres;i++) {
			Pessoa mulher = new Pessoa("Mulher", i);
			Thread threadmulher = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while(true) {
						banheiro.entraMulher(mulher);
						
						try {
							Thread.sleep(mulher.tempoDentroOuFora());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						banheiro.saiMulher(mulher);
						
						try {
							Thread.sleep(mulher.tempoDentroOuFora());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}, "Mulher " + String.valueOf(mulher.getIdentificador()));
			threadmulher.start();
		}

	}

}
