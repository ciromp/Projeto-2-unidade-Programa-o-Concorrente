package montanhaRussa;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(">>>> Bem - Vindos a Montanha Russa! <<<<");
		System.out.println("----------------------------------------");
		System.out.println("");

		// args[0] é a quantidade máxima permitida no carro
		// args[2] é o número de passeios que podem ocorrer diariamente
		Carro carro = new Carro(Integer.parseInt(args[0]), Integer.parseInt(args[2]));

		// args[1] é o número de pessoas que irão participar
		int numeroPassageiros = Integer.parseInt(args[1]);

		// instanciando e inicializando o carro da montanha russa
		Thread threadCarro = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (!carro.finalizaMontanhaRussa()) {
					// aqui comeca a volta na montanha russa
					carro.load();
					try {

						Thread.sleep(5000);

					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e.getMessage().toString());
					}
					// aqui termina a volta na montanha russa
					carro.unload();
					if (carro.finalizaMontanhaRussa()) {
						try {

							this.finalize();

						} catch (Throwable e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}, "Carro Thread");

		// start no carro
		threadCarro.start();

		// instanciando e inicializando os passageiros
		for (int i = 0; i < numeroPassageiros; i++) {
			Pessoa pessoa = new Pessoa(i);
			Thread passageiro = new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub

					while (!carro.finalizaMontanhaRussa()) {
						// aqui o passageiro entra no carro
						if (carro.finalizaMontanhaRussa()) {
							try {
								this.finalize();
							} catch (Throwable e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} else {
							if (pessoa.isSaiuDoCarro()) {
								try {
									Thread.sleep(pessoa.getTempoPasseandoFora());
									pessoa.board(carro);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							} else {
								pessoa.board(carro);
							}

						}
					}

				}
			}, "Passageiro" + String.valueOf(pessoa.getIdentificador()));

			// start no passageiro
			passageiro.start();
		}

	}

}
