package montanhaRussa;

import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Carro {

	private ArrayList<Pessoa> pessoasNoCarro;

	private int capacidadeTotal;

	private boolean esperandoLotar;

	private ReentrantLock bloqueio;

	private int numPasseiosDiarios;
	private int passeioAtual = 0;

	private Condition carroEstaCheio;
	private Condition carroSaindoPassageiros;
	private Condition carroPassageirosEntram;

	public Carro(int capacidadeMaxima, int numPasseiosDiarios) {
		super();
		// TODO Auto-generated constructor stub
		this.capacidadeTotal = capacidadeMaxima;
		this.pessoasNoCarro = new ArrayList<Pessoa>();
		this.bloqueio = new ReentrantLock();
		this.carroEstaCheio = bloqueio.newCondition();
		this.carroSaindoPassageiros = bloqueio.newCondition();
		this.carroPassageirosEntram = bloqueio.newCondition();
		this.numPasseiosDiarios = numPasseiosDiarios;
	}

	public void entraPassageiro(Pessoa passageiro) {
		bloqueio.lock();
		if (passeioAtual != numPasseiosDiarios) {
			while (esperandoLotar = false || pessoasNoCarro.size() == capacidadeTotal) {
				System.out.println("O passageiro " + passageiro.getIdentificador() + " Está esperando para entrar!");
				carroPassageirosEntram.awaitUninterruptibly();
			}

			pessoasNoCarro.add(passageiro);
			System.out.println("O passageiro " + passageiro.getIdentificador() + " ENTROU no carro!");

			if (pessoasNoCarro.size() == capacidadeTotal) {

				carroEstaCheio.signalAll();
			}

			// fica esperando aqui até que o carro lote
			carroEstaCheio.awaitUninterruptibly();

			// fica parado aqui até terminar a volta do carro
			carroSaindoPassageiros.awaitUninterruptibly();

			System.out.println("O passageiro " + passageiro.getIdentificador() + " SAIU do carro!");
			passageiro.unboard();
		}
		bloqueio.unlock();
	}

	public void load() {
		bloqueio.lock();
		if (passeioAtual != numPasseiosDiarios) {
			// fica aqui esperando o carro esvaziar para que outros passageiros
			// possam entrar
			while (pessoasNoCarro.size() > 0) {
				carroSaindoPassageiros.awaitUninterruptibly();
			}

			if (!finalizaMontanhaRussa()) {
				esperandoLotar = true;

				carroPassageirosEntram.signalAll();

				System.out.println("Agora o carro está esperando os passageiros entrarem!");
			}
			// fica aqui esperando até o carro lotar
			carroEstaCheio.awaitUninterruptibly();
			esperandoLotar = false;

			System.out.println("O carro LOTOU! agora se INICIA a volta na montanha russa!" + " Passeio número: "
					+ String.valueOf(passeioAtual + 1) + " Número de passeios permitidos: "
					+ String.valueOf(numPasseiosDiarios));
		}
		bloqueio.unlock();
	}

	public void unload() {
		bloqueio.lock();
		pessoasNoCarro.clear();
		passeioAtual++;
		System.out.println("FIM do passeio " + String.valueOf(passeioAtual) + " na montanha Russa, carro estacionado!");
		if (!finalizaMontanhaRussa()) {
			carroSaindoPassageiros.signalAll();
			System.out.println("TODOS os passageiros SAÍRAM.");
		} else {
			System.out.println("TODOS os passageiros SAÍRAM. E a montanha russa acabou por hoje!");
		}
		bloqueio.unlock();
	}

	public boolean finalizaMontanhaRussa() {
		if (passeioAtual >= numPasseiosDiarios) {
			return true;
		} else {
			return false;
		}
	}
}
