
import java.util.Random;

public class Pessoa {

	private int identificador;
	private boolean saiuDoCarro = false;
	private long tempoPasseandoFora = 0;

	public Pessoa(int id) {
		super();
		// TODO Auto-generated constructor stub
		this.identificador = id;
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	public void board(Carro c) {
		saiuDoCarro = false;
		c.entraPassageiro(this);
	}

	public void unboard() {

		Random rand = new Random();

		// Gerando tempo aleatório que a pessoa irá passar sem participar da
		// Montanha Russa
		int tempoAleatorio = rand.nextInt((5 - 1) + 1) + 1;
		saiuDoCarro = true;

		tempoPasseandoFora = tempoAleatorio * 1000;
	}

	public boolean isSaiuDoCarro() {
		return saiuDoCarro;
	}

	public void setSaiuDoCarro(boolean saiuDoCarro) {
		this.saiuDoCarro = saiuDoCarro;
	}

	public long getTempoPasseandoFora() {
		return tempoPasseandoFora;
	}

	public void setTempoPasseandoFora(long tempoPasseandoFora) {
		this.tempoPasseandoFora = tempoPasseandoFora;
	}

}
