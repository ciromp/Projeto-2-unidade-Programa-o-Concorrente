
import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class Carro {

	private int capacidadeTotal;

	private boolean esperandoLotar;

	private ArrayList<Pessoa> pessoasNoCarro;

	private int numPasseiosDiarios;
	private int passeioAtual = 0;

	private Semaphore semaforo;

	public Carro(int capacidadeMaxima, int numPasseiosDiarios, Semaphore semaforo) {
		super();
		// TODO Auto-generated constructor stub
		this.capacidadeTotal = capacidadeMaxima;
		this.numPasseiosDiarios = numPasseiosDiarios;
		this.semaforo = semaforo;
		this.pessoasNoCarro = new ArrayList<Pessoa>();
		this.esperandoLotar = true;
	}

	public void entraPassageiro(Pessoa passageiro) {

		if (passeioAtual != numPasseiosDiarios && !pessoasNoCarro.contains(passageiro)) {

			System.out.println("O passageiro " + passageiro.getIdentificador() + " Está esperando para entrar!");
			while (!esperandoLotar) {
				synchronized (semaforo) {
					try {
						semaforo.wait();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
			if (esperandoLotar) {
				try {
					semaforo.acquire();
					pessoasNoCarro.add(passageiro);
					if (pessoasNoCarro.size() == capacidadeTotal) {

						synchronized (semaforo) {
							try {
								semaforo.notifyAll();
								esperandoLotar = false;
							} catch (Exception e) {
								// TODO: handle exception
							}
						}
					}
					System.out.println("O passageiro " + passageiro.getIdentificador() + " ENTROU no carro!");
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}

	public void saiPassageiro(Pessoa passageiro) {

		System.out.println("O passageiro " + passageiro.getIdentificador() + " SAIU do carro!");
		passageiro.unboard();
		semaforo.release();

	}

	public void load() {
		if (passeioAtual < numPasseiosDiarios) {
			// fica aqui esperando o carro esvaziar para que outros passageiros
			// possam entrar

			// fica aqui esperando até o carro lotar

			while (esperandoLotar) {
				synchronized (semaforo) {
					try {
						semaforo.wait();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}

			System.out.println("O carro LOTOU! agora se INICIA a volta na montanha russa! Passeio número: "
					+ String.valueOf(passeioAtual + 1) + " Número de passeios permitidos: "
					+ String.valueOf(numPasseiosDiarios));
			passeioAtual++;
		}
	}

	public void unload() {

		for (int i = 0; i < pessoasNoCarro.size(); i++) {
			saiPassageiro(pessoasNoCarro.get(i));
		}
		synchronized (semaforo) {
			try {
				semaforo.notifyAll();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		pessoasNoCarro.clear();
		if (!finalizaMontanhaRussa())
			esperandoLotar = true;
		System.out.println("FIM do passeio " + String.valueOf(passeioAtual) + " na montanha Russa, carro estacionado!");
		if (passeioAtual < numPasseiosDiarios) {
			System.out.println("TODOS os passageiros SAÍRAM.");
		} else {
			System.out.println("TODOS os passageiros SAÍRAM. E a montanha russa acabou por hoje!");
		}

	}

	public boolean finalizaMontanhaRussa() {
		if (passeioAtual >= numPasseiosDiarios) {
			return true;
		} else {
			return false;
		}
	}
}
