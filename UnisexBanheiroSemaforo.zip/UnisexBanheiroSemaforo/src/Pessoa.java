import java.util.Random;

public class Pessoa {

	private String sexo;
	private int identificador;

	public Pessoa() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pessoa(String sexo, int identificador) {
		super();
		this.sexo = sexo;
		this.identificador = identificador;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	public long tempoDentroOuFora() {

		Random rand = new Random();
		int tempoAleatorio = rand.nextInt((5 - 1) + 1) + 1;

		return tempoAleatorio * 1000;
	}

}
