import java.util.concurrent.Semaphore;

public class Banheiro {

	private int capacidadeMax;
	private int qntHomensDentro;
	private int qntMulheresDentro;
	private int totalDentroBanheiro;

	private Semaphore semaforo;

	public Banheiro(int capacidadeMax, Semaphore semaphore) {
		super();
		// TODO Auto-generated constructor stub
		this.capacidadeMax = capacidadeMax;
		this.semaforo = semaphore;
		this.qntMulheresDentro = 0;
		this.qntHomensDentro = 0;
		this.totalDentroBanheiro = 0;

	}

	public void entraMulher(Pessoa mulher) {
		try {

			semaforo.acquire();

			while (capacidadeMax == totalDentroBanheiro || qntHomensDentro > 0) {
				synchronized (semaforo) {
					try {
						semaforo.wait();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
			qntMulheresDentro++;
			totalDentroBanheiro++;

			System.out.println("A mulher " + String.valueOf(mulher.getIdentificador())
					+ " ENTROU NO BANHEIRO! > PESSOAS NO BANHEIRO: " + String.valueOf(totalDentroBanheiro)
					+ " MULHER(ES)");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void entraHomem(Pessoa homem) {
		try {

			semaforo.acquire();
			while (capacidadeMax == totalDentroBanheiro || qntMulheresDentro > 0) {
				synchronized (semaforo) {
					try {
						semaforo.wait();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}

			qntHomensDentro++;
			totalDentroBanheiro++;

			System.out.println("O homem " + String.valueOf(homem.getIdentificador())
					+ " ENTROU no banheiro! > PESSOAS NO BANHEIRO: " + String.valueOf(totalDentroBanheiro)
					+ " HOMEM(ENS)");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void saiMulher(Pessoa mulher) {

		qntMulheresDentro--;
		totalDentroBanheiro--;

		System.out.println("A mulher " + String.valueOf(mulher.getIdentificador()) + " SAIU do banheiro!");
		semaforo.release();
		if (qntMulheresDentro == 0) {
			try {
				synchronized (semaforo) {
					notifyAll();
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	public void saiHomem(Pessoa homem) {

		qntHomensDentro--;
		totalDentroBanheiro--;

		System.out.println("O homem " + String.valueOf(homem.getIdentificador()) + " SAIU do banheiro!");
		semaforo.release();
		if (qntHomensDentro == 0) {
			try {
				synchronized (semaforo) {
					semaforo.notifyAll();
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

}
